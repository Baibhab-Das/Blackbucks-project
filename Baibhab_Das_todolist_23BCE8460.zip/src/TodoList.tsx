import { FormEvent, useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { Id } from "../convex/_generated/dataModel";

export function TodoList() {
  const tasks = useQuery(api.tasks.getTasks) || [];
  const createTask = useMutation(api.tasks.createTask);
  const updateTaskStatus = useMutation(api.tasks.updateTaskStatus);
  const deleteTask = useMutation(api.tasks.deleteTask);

  const [newTaskText, setNewTaskText] = useState("");

  const handleCreateTask = async (event: FormEvent) => {
    event.preventDefault();
    if (newTaskText.trim() === "") return;
    await createTask({ text: newTaskText });
    setNewTaskText("");
  };

  const handleToggleComplete = async (taskId: Id<"tasks">, completed: boolean) => {
    await updateTaskStatus({ taskId, completed: !completed });
  };

  const handleDeleteTask = async (taskId: Id<"tasks">) => {
    await deleteTask({ taskId });
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-semibold mb-4 text-primary">My To-Do List</h2>
      <form onSubmit={handleCreateTask} className="flex gap-2 mb-4">
        <input
          type="text"
          value={newTaskText}
          onChange={(e) => setNewTaskText(e.target.value)}
          placeholder="Add a new task"
          className="flex-grow px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
        />
        <button
          type="submit"
          className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-hover transition-colors disabled:opacity-50"
          disabled={!newTaskText.trim()}
        >
          Add Task
        </button>
      </form>
      {tasks.length === 0 && <p className="text-gray-500">No tasks yet. Add one above!</p>}
      <ul className="space-y-2">
        {tasks.map((task) => (
          <li
            key={task._id}
            className={`flex items-center justify-between p-3 rounded-md transition-colors ${
              task.completed ? "bg-green-50 line-through text-gray-500" : "bg-gray-50"
            }`}
          >
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={task.completed}
                onChange={() => handleToggleComplete(task._id, task.completed)}
                className="mr-3 h-5 w-5 text-primary focus:ring-primary border-gray-300 rounded"
              />
              <span className={task.completed ? "text-gray-500" : "text-gray-800"}>{task.text}</span>
            </div>
            <button
              onClick={() => handleDeleteTask(task._id)}
              className="text-red-500 hover:text-red-700 transition-colors font-medium"
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
