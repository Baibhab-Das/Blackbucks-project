import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { TodoList } from "./TodoList"; // Import the TodoList component

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm h-16 flex justify-between items-center border-b shadow-sm px-4">
        <h2 className="text-xl font-semibold text-primary">To-Do</h2> {/* Changed title here */}
        <SignOutButton />
      </header>
      <main className="flex-1 flex items-start justify-center p-8 pt-12"> {/* Changed items-center to items-start and added pt-12 */}
        <div className="w-full max-w-lg mx-auto"> {/* Changed max-w-md to max-w-lg */}
          <Content />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-8"> {/* Increased gap */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-primary mb-2">Organize Your Day</h1> {/* Changed text and size */}
        <Authenticated>
          <p className="text-lg text-secondary"> {/* Changed size */}
            Welcome back, {loggedInUser?.name ?? loggedInUser?.email ?? "friend"}!
          </p>
        </Authenticated>
        <Unauthenticated>
          <p className="text-lg text-secondary">Sign in to manage your tasks.</p> {/* Changed text and size */}
        </Unauthenticated>
      </div>

      <Unauthenticated>
        <SignInForm />
      </Unauthenticated>
      <Authenticated>
        <TodoList /> {/* Add TodoList component here */}
      </Authenticated>
    </div>
  );
}
